import numpy as np
import math

class Distance:
    @staticmethod
    def calculateCosineDistance(x, y):
        pass
    @staticmethod
    def calculateMinkowskiDistance(x, y, p=2):
        pass
    @staticmethod
    def calculateMahalanobisDistance(x,y, S_minus_1):
        pass

